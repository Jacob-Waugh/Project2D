using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class Buttons : MonoBehaviour
{
    public Image blackPanel;
    public Animator fadeAnimation;

    public AudioSource music;
    public AudioSource textClick;

    // Start is called before the first frame update
    void Start()
    {
        music.Play();
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    public void OnStartClick()
    {
        textClick.Play();
        StartCoroutine(Fading("Level1"));

    }

    public void OnOptionsClick()
    {
        textClick.Play();
        StartCoroutine(Fading("Options"));

    }

    public void OnBackClick()
    {
        textClick.Play();
        StartCoroutine(Fading("Main"));

    }

    IEnumerator Fading(string sceneName)
    {
        fadeAnimation.SetBool("Fade", true);
        yield return new WaitUntil(() => blackPanel.color.a == 1);
        SceneManager.LoadScene(sceneName);
    }
}
